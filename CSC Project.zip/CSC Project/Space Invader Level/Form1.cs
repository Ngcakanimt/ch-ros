﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Invader_Level
{
    public partial class Form1 : Form
    {
        bool goleft;
        bool goright;
        int speed = 30;
        int score = 0;
        bool isPressed;
        int totalEnemies = 12;
        int playerSpeed = 50;


        public Form1()
        {
            InitializeComponent();
        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goleft = true;
            }

            if (e.KeyCode == Keys.Right)
            {
                goright = true;
            }

            if (e.KeyCode == Keys.Space && !isPressed)
            {
                isPressed = true;

                makeBullet();
            }
        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goleft = false;
            }

            if (e.KeyCode == Keys.Right)
            {
                goright = false;
            }

            if (isPressed)
            {
                isPressed = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //player moving left and right
            if (goleft)
            {
                Player.Left -= playerSpeed;
            }
            else if (goright)
            {
                Player.Left += playerSpeed;
            }
            // end of player moving left and right

            //enemies moving on the form
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag == "Invaders")
                {
                    if (((PictureBox)x).Bounds.IntersectsWith(Player.Bounds))
                    {
                        gameOver();
                    }
                    ((PictureBox)x).Left += speed;

                    if (((PictureBox)x).Left > 720)
                    {
                        ((PictureBox)x).Top += ((PictureBox)x).Height + 10;

                        ((PictureBox)x).Left = -50;
                    }
                }
            }

            foreach (Control w in this.Controls)
            {
                if (w is PictureBox && w.Tag == "ColorInvader")
                {
                    if (((PictureBox)w).Bounds.IntersectsWith(Player.Bounds))
                    {
                        gameOver();
                    }
                    ((PictureBox)w).Left += speed;

                    if (((PictureBox)w).Left > 720)
                    {
                        ((PictureBox)w).Top += ((PictureBox)w).Height + 10;

                        ((PictureBox)w).Left = -50;
                    }
                }
            }

            // end of enemies moving on the form

            foreach (Control y in this.Controls)
            {
                if (y is PictureBox && y.Tag == "bullet")
                {
                    y.Top -= 20;

                    if (((PictureBox)y).Top < this.Height - 490)
                    {
                        this.Controls.Remove(y);
                    }
                }
            }
            // end of animating the bullets

            foreach (Control i in this.Controls)
            {
                foreach (Control j in this.Controls)
                {                   
                        if (i is PictureBox && i.Tag == "Invaders")
                        {
                            if (j is PictureBox && j.Tag == "bullet")
                            {                               
                                    if (i.Bounds.IntersectsWith(j.Bounds))
                                    {
                                        score++;
                                        this.Controls.Remove(i);
                                        this.Controls.Remove(j);
                                    }

                                    
                                
                               
                            }
                        }                    
                }
                
            }

            foreach (Control a in this.Controls)
            {
                foreach (Control b in this.Controls)
                {
                    if (a is PictureBox && a.Tag == "ColorInvader")
                    {
                        if (b is PictureBox && b.Tag == "bullet")
                        {
                            if (a.Bounds.IntersectsWith(b.Bounds))
                            {
                                this.Controls.Remove(a);
                                this.Controls.Remove(b);

                                if (score > 0)
                                {
                                    score = score - 1;
                                }
                                if (score <= 0)
                                {
                                    score = 0;
                                }
                               

                            }




                        }
                    }
                }

            }

            //showing score
            label1.Text = "Score : " + score;
            if (score > totalEnemies -1)
            {
                gameOver();
                MessageBox.Show("You Win!");
            }
            //end of showing score
        }



        private void makeBullet()
        {
            PictureBox bullet = new PictureBox();
            bullet.Image = Properties.Resources.bulletsilver;
            bullet.Size = new Size(5, 20);
            bullet.Tag = "bullet";
            bullet.Left = Player.Left + Player.Width / 2;
            bullet.Top = Player.Top - 20;
            this.Controls.Add(bullet);
            bullet.BringToFront();
        }

        private void gameOver()
        {
            timer1.Stop();
            string gamescore = score.ToString();
            
            MessageBox.Show("Game Over \nGame Score: " + gamescore);
           
          
         
        }
    }

    
}
